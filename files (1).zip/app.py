"""
app.py - Pallet Tracking & Location Web App (minimal)

Run:
    python app.py

On first run the app will create data.db (SQLite) and seed warehouse locations (W1 & W2).
"""
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data.db")

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "dev-secret"

db = SQLAlchemy(app)


# -----------------------
# Models
# -----------------------
class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(128), unique=True, nullable=False)  # e.g. W1-A1-R1-B07-L4
    warehouse_code = db.Column(db.String(16), nullable=False)      # "W1" / "W2"
    aisle = db.Column(db.Integer, nullable=False, default=0)       # 1..3
    row = db.Column(db.Integer, nullable=False, default=0)         # 1..6
    bay = db.Column(db.Integer, nullable=False, default=0)         # 1..15
    level = db.Column(db.Integer, nullable=False, default=0)       # 1..6
    is_staging = db.Column(db.Boolean, default=False)              # staging / dock zones
    status = db.Column(db.String(32), default="ACTIVE")
    notes = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f"<Location {self.code}>"


class Shipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    direction = db.Column(db.String(16), nullable=False)  # INBOUND / OUTBOUND
    invoice_number = db.Column(db.String(64), nullable=True)
    trailer_reg = db.Column(db.String(64), nullable=True)
    counterparty_name = db.Column(db.String(128), nullable=True)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(32), default="PLANNED")  # PLANNED / IN_PROGRESS / COMPLETE
    notes = db.Column(db.Text, nullable=True)

    lines = db.relationship("ShipmentLine", backref="shipment", cascade="all,delete-orphan")

    def __repr__(self):
        return f"<Shipment {self.id} {self.direction} {self.invoice_number}>"


class ShipmentLine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    shipment_id = db.Column(db.Integer, db.ForeignKey("shipment.id"), nullable=False)
    product_description = db.Column(db.String(256), nullable=False)
    expected_pallets = db.Column(db.Integer, nullable=True)
    expected_quantity = db.Column(db.Integer, nullable=True)
    notes = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f"<ShipmentLine {self.id} {self.product_description}>"


class Pallet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pallet_code = db.Column(db.String(64), unique=True, nullable=False)  # e.g. P000123
    product_description = db.Column(db.String(256), nullable=True)
    customer = db.Column(db.String(128), nullable=True)
    quantity = db.Column(db.Integer, nullable=True)
    weight_kg = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(32), default="IN_WAREHOUSE")  # IN_WAREHOUSE / ON_TRAILER / SHIPPED / DAMAGED
    arrival_shipment_id = db.Column(db.Integer, db.ForeignKey("shipment.id"), nullable=True)
    due_out_shipment_id = db.Column(db.Integer, db.ForeignKey("shipment.id"), nullable=True)
    current_location_id = db.Column(db.Integer, db.ForeignKey("location.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    movements = db.relationship("Movement", backref="pallet", cascade="all,delete-orphan")
    location = db.relationship("Location", primaryjoin="Pallet.current_location_id==Location.id", backref="pallets", lazy="joined")

    def __repr__(self):
        return f"<Pallet {self.pallet_code}>"


class Movement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pallet_id = db.Column(db.Integer, db.ForeignKey("pallet.id"), nullable=False)
    from_location_id = db.Column(db.Integer, db.ForeignKey("location.id"), nullable=True)
    to_location_id = db.Column(db.Integer, db.ForeignKey("location.id"), nullable=True)
    movement_type = db.Column(db.String(32), nullable=False)  # PUTAWAY / PICK / RELOCATION / CORRECTION
    operator_name = db.Column(db.String(128), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    from_location = db.relationship("Location", foreign_keys=[from_location_id], lazy="joined", backref="movement_from")
    to_location = db.relationship("Location", foreign_keys=[to_location_id], lazy="joined", backref="movement_to")

    def __repr__(self):
        return f"<Movement {self.movement_type} pallet={self.pallet_id} at {self.timestamp}>"


# -----------------------
# DB seed helper
# -----------------------
def seed_locations():
    """
    Seed locations for W1 and W2:
    aisles 1..3, rows 1..6, bays 1..15, levels 1..6
    plus a couple of staging locations per warehouse
    """
    existing = Location.query.first()
    if existing:
        return

    warehouses = ["W1", "W2"]
    aisles = range(1, 4)
    rows = range(1, 7)
    bays = range(1, 16)
    levels = range(1, 7)

    for wh in warehouses:
        for a in aisles:
            for r in rows:
                for b in bays:
                    for l in levels:
                        code = f"{wh}-A{a}-R{r}-B{b:02d}-L{l}"
                        loc = Location(
                            code=code,
                            warehouse_code=wh,
                            aisle=a,
                            row=r,
                            bay=b,
                            level=l,
                            is_staging=False,
                            status="ACTIVE"
                        )
                        db.session.add(loc)
    # staging spots
    for wh in warehouses:
        for s in range(1, 3):
            code = f"{wh}-STAGE-S{s}-B01"
            loc = Location(
                code=code,
                warehouse_code=wh,
                aisle=0,
                row=0,
                bay=s,
                level=0,
                is_staging=True,
                status="ACTIVE",
                notes="Dock / staging"
            )
            db.session.add(loc)

    db.session.commit()


# -----------------------
# Utility
# -----------------------
def get_location_by_code(code: str):
    if not code:
        return None
    code = code.strip()
    return Location.query.filter_by(code=code).first()


def get_or_create_location(code: str):
    loc = get_location_by_code(code)
    if loc:
        return loc
    # minimal parse for pattern like W1-A1-R1-B01-L1 or W1-STAGE-S1-B01
    parts = code.split("-")
    if len(parts) >= 2 and parts[0].upper().startswith("W"):
        # create a simple staging or full location
        if "STAGE" in code.upper():
            loc = Location(code=code, warehouse_code=parts[0].upper(), aisle=0, row=0, bay=1, level=0, is_staging=True, status="ACTIVE")
            db.session.add(loc)
            db.session.commit()
            return loc
        else:
            # best-effort create: not robust but suffices for scanning typed codes
            loc = Location(code=code, warehouse_code=parts[0].upper(), aisle=0, row=0, bay=0, level=0, is_staging=False, status="ACTIVE")
            db.session.add(loc)
            db.session.commit()
            return loc
    return None


def find_pallet_by_code(code: str):
    if not code:
        return None
    return Pallet.query.filter(Pallet.pallet_code.ilike(code.strip())).first()


# -----------------------
# Routes
# -----------------------
@app.route("/")
def dashboard():
    total = Pallet.query.count()
    in_wh = Pallet.query.filter_by(status="IN_WAREHOUSE").count()
    on_trailer = Pallet.query.filter_by(status="ON_TRAILER").count()
    shipped = Pallet.query.filter_by(status="SHIPPED").count()
    inbound_progress = Shipment.query.filter_by(direction="INBOUND", status="IN_PROGRESS").count()
    outbound_progress = Shipment.query.filter_by(direction="OUTBOUND", status="IN_PROGRESS").count()
    return render_template("dashboard.html",
                           total=total, in_wh=in_wh, on_trailer=on_trailer, shipped=shipped,
                           inbound_progress=inbound_progress, outbound_progress=outbound_progress)


# Find pallet / invoice quick-search
@app.route("/find", methods=["GET", "POST"])
def find():
    result = None
    shipments = []
    q = ""
    if request.method == "POST":
        q = (request.form.get("q") or "").strip()
        if not q:
            flash("Enter pallet code or invoice number", "warning")
            return redirect(url_for("find"))
        # try pallet first
        pallet = find_pallet_by_code(q)
        if pallet:
            return redirect(url_for("pallet_detail", pallet_id=pallet.id))
        # else find shipments by invoice
        shipments = Shipment.query.filter(Shipment.invoice_number.ilike(f"%{q}%")).all()
        if shipments:
            return render_template("find.html", query=q, shipments=shipments)
        flash("No pallet or shipment found", "info")
    return render_template("find.html", query=q, shipments=shipments)


# Pallet detail
@app.route("/pallets/<int:pallet_id>")
def pallet_detail(pallet_id):
    p = Pallet.query.get_or_404(pallet_id)
    movements = Movement.query.filter_by(pallet_id=p.id).order_by(Movement.timestamp.desc()).all()
    return render_template("pallet_detail.html", pallet=p, movements=movements)


# Receive inbound: create inbound shipment, then receive pallets
@app.route("/shipments/inbound/create", methods=["GET", "POST"])
def create_inbound():
    if request.method == "POST":
        invoice = request.form.get("invoice_number")
        trailer = request.form.get("trailer_reg")
        supplier = request.form.get("counterparty_name")
        shipment = Shipment(direction="INBOUND", invoice_number=invoice, trailer_reg=trailer, counterparty_name=supplier, status="IN_PROGRESS")
        db.session.add(shipment)
        db.session.commit()
        return redirect(url_for("receive_inbound", shipment_id=shipment.id))
    return render_template("receive_inbound.html", shipment=None)


@app.route("/shipments/<int:shipment_id>/receive", methods=["GET", "POST"])
def receive_inbound(shipment_id):
    shipment = Shipment.query.get_or_404(shipment_id)
    if shipment.direction != "INBOUND":
        flash("Not an inbound shipment", "warning")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        pallet_code = (request.form.get("pallet_code") or "").strip()
        product = request.form.get("product_description")
        customer = request.form.get("customer") or shipment.counterparty_name
        qty = request.form.get("quantity") or None
        weight = request.form.get("weight_kg") or None
        location_code = (request.form.get("location_code") or "").strip()
        operator = request.form.get("operator_name") or None

        if not pallet_code or not location_code:
            flash("Pallet code and location are required", "danger")
            return redirect(url_for("receive_inbound", shipment_id=shipment_id))

        pallet = find_pallet_by_code(pallet_code)
        if not pallet:
            pallet = Pallet(pallet_code=pallet_code, product_description=product, customer=customer,
                            quantity=int(qty) if qty else None, weight_kg=float(weight) if weight else None,
                            status="IN_WAREHOUSE", arrival_shipment_id=shipment.id)
            db.session.add(pallet)
            db.session.commit()
        else:
            pallet.arrival_shipment_id = pallet.arrival_shipment_id or shipment.id
            pallet.product_description = pallet.product_description or product
            db.session.commit()

        loc = get_or_create_location(location_code)
        mv = Movement(pallet_id=pallet.id, from_location_id=None, to_location_id=loc.id, movement_type="PUTAWAY", operator_name=operator)
        pallet.current_location_id = loc.id
        db.session.add(mv)
        db.session.commit()
        flash(f"Pallet {pallet.pallet_code} received to {loc.code}", "success")
        return redirect(url_for("receive_inbound", shipment_id=shipment_id))

    # list pallets received for this shipment
    received = Pallet.query.filter_by(arrival_shipment_id=shipment.id).order_by(Pallet.created_at.desc()).all()
    return render_template("receive_inbound.html", shipment=shipment, received=received)


# Create outbound shipment
@app.route("/shipments/outbound/create", methods=["GET", "POST"])
def create_outbound():
    if request.method == "POST":
        invoice = request.form.get("invoice_number")
        trailer = request.form.get("trailer_reg")
        customer = request.form.get("counterparty_name")
        shipment = Shipment(direction="OUTBOUND", invoice_number=invoice, trailer_reg=trailer, counterparty_name=customer, status="PLANNED")
        db.session.add(shipment)
        db.session.commit()
        return redirect(url_for("allocate_outbound", shipment_id=shipment.id))
    return render_template("load_outbound.html", shipment=None)


@app.route("/shipments/<int:shipment_id>/allocate", methods=["GET", "POST"])
def allocate_outbound(shipment_id):
    shipment = Shipment.query.get_or_404(shipment_id)
    if shipment.direction != "OUTBOUND":
        flash("Not an outbound shipment", "warning")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        # simple add line
        product = request.form.get("product_description")
        expected_pallets = request.form.get("expected_pallets") or None
        if product:
            line = ShipmentLine(shipment_id=shipment.id, product_description=product, expected_pallets=int(expected_pallets) if expected_pallets else None)
            db.session.add(line)
            db.session.commit()
            flash("Line added", "success")
        # auto-allocate button
        if request.form.get("action") == "auto_allocate":
            for line in shipment.lines:
                needed = (line.expected_pallets or 0)
                already = Pallet.query.filter_by(due_out_shipment_id=shipment.id).filter(Pallet.product_description == line.product_description).count()
                to_alloc = max(0, needed - already)
                if to_alloc <= 0:
                    continue
                candidates = Pallet.query.filter_by(product_description=line.product_description, status="IN_WAREHOUSE", due_out_shipment_id=None).order_by(Pallet.created_at.asc()).limit(to_alloc).all()
                for p in candidates:
                    p.due_out_shipment_id = shipment.id
                db.session.commit()
            flash("Auto-allocation completed", "success")
        return redirect(url_for("allocate_outbound", shipment_id=shipment_id))
    # show lines and candidate pallets
    line_info = []
    for line in shipment.lines:
        candidates = Pallet.query.filter_by(product_description=line.product_description, status="IN_WAREHOUSE", due_out_shipment_id=None).order_by(Pallet.created_at.asc()).limit(20).all()
        allocated = Pallet.query.filter_by(due_out_shipment_id=shipment.id).filter(Pallet.product_description == line.product_description).all()
        line_info.append({"line": line, "candidates": candidates, "allocated": allocated})
    return render_template("load_outbound.html", shipment=shipment, line_info=line_info)


@app.route("/shipments/<int:shipment_id>/pick", methods=["GET", "POST"])
def pick_outbound(shipment_id):
    shipment = Shipment.query.get_or_404(shipment_id)
    if shipment.direction != "OUTBOUND":
        flash("Not an outbound shipment", "warning")
        return redirect(url_for("dashboard"))

    allocated = Pallet.query.filter_by(due_out_shipment_id=shipment.id).all()
    # sort by location for a simple route
    allocated_sorted = sorted(allocated, key=lambda p: (p.location.warehouse_code if p.location else "", p.location.aisle if p.location else 0, p.location.bay if p.location else 0, p.location.row if p.location else 0, p.location.level if p.location else 0))

    if request.method == "POST":
        pallet_code = (request.form.get("pallet_code") or "").strip()
        dest_code = (request.form.get("dest_location_code") or "").strip()
        operator = request.form.get("operator_name") or None
        if not pallet_code or not dest_code:
            flash("Pallet code and destination are required", "danger")
            return redirect(url_for("pick_outbound", shipment_id=shipment_id))
        pallet = find_pallet_by_code(pallet_code)
        if not pallet:
            flash("Pallet not found", "danger")
            return redirect(url_for("pick_outbound", shipment_id=shipment_id))
        if pallet.due_out_shipment_id != shipment.id:
            flash("Pallet not allocated to this shipment", "danger")
            return redirect(url_for("pick_outbound", shipment_id=shipment_id))
        dest_loc = get_or_create_location(dest_code)
        mv = Movement(pallet_id=pallet.id, from_location_id=pallet.current_location_id, to_location_id=dest_loc.id, movement_type="PICK", operator_name=operator)
        pallet.current_location_id = dest_loc.id
        # if destination is staging, set ON_TRAILER; otherwise leave
        if dest_loc and dest_loc.is_staging:
            pallet.status = "ON_TRAILER"
        db.session.add(mv)
        db.session.commit()
        flash(f"Pallet {pallet.pallet_code} moved to {dest_loc.code}", "success")
        return redirect(url_for("pick_outbound", shipment_id=shipment_id))

    picked = sum(1 for p in allocated_sorted if (p.location and p.location.is_staging) or p.status in ("ON_TRAILER", "SHIPPED"))
    total = len(allocated_sorted)
    return render_template("load_outbound.html", shipment=shipment, allocated=allocated_sorted, picked=picked, total=total)


# Locations / Aisle map
@app.route("/locations")
def locations_index():
    # show warehouses available
    whs = db.session.query(Location.warehouse_code).distinct().all()
    warehouses = [w[0] for w in whs if w[0]]
    if not warehouses:
        warehouses = ["W1", "W2"]
    return render_template("locations.html", warehouses=warehouses)


@app.route("/locations/<warehouse_code>/<int:aisle>")
def locations_aisle(warehouse_code, aisle):
    bays = list(range(1, 16))
    levels = list(range(1, 7))
    # grid: bay x level, each cell shows rows R1..R6
    grid = []
    for bay in bays:
        row_cells = []
        for level in levels:
            locs = Location.query.filter_by(warehouse_code=warehouse_code, aisle=aisle, bay=bay, level=level).order_by(Location.row).all()
            rows = []
            for r in range(1, 7):
                loc = next((x for x in locs if x.row == r), None)
                rows.append({"row": r, "location": loc, "pallet": (loc.pallets[0] if loc and loc.pallets else None)})
            row_cells.append(rows)
        grid.append({"bay": bay, "cells": row_cells})
    return render_template("locations.html", warehouse_code=warehouse_code, aisle=aisle, bays=bays, levels=levels, grid=grid)


# -----------------------
# App start (create + seed DB if missing)
# -----------------------
if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        with app.app_context():
            db.create_all()
            seed_locations()
            print("Initialized database and seeded locations (W1 & W2).")
    # start Flask on port 5000
    app.run(host="0.0.0.0", port=5000, debug=True)