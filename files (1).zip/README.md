```markdown
# Pallet Tracking & Location Web App (Minimal)

This is a small Flask web application to track pallets and their locations across two warehouses (W1, W2).

Features (minimal):
- Models: Location, Pallet, Shipment, ShipmentLine, Movement (SQLAlchemy + SQLite)
- Seeded locations for W1/W2 (aisles 1-3, rows 1-6, bays 1-15, levels 1-6) + staging spots
- Screens:
  - Dashboard (/)
  - Find pallet / invoice (/find)
  - Receive inbound shipment and receive pallets
  - Create outbound shipment, allocate and pick/load pallets
  - Locations / aisle map (/locations and /locations/&lt;warehouse&gt;/&lt;aisle&gt;)
  - Pallet detail pages

Requirements
------------
- Python 3.8+
- See requirements.txt

Install
-------
1. Create a virtual environment (recommended)
   python -m venv venv
   source venv/bin/activate  (Linux/macOS)
   venv\Scripts\activate     (Windows)

2. Install dependencies:
   pip install -r requirements.txt

Run
---
1. Start the app:
   python app.py

   On first run the app will create `data.db` and seed locations automatically.

2. Open your browser:
   http://127.0.0.1:5000/

Notes
-----
- The app auto-creates the database file `data.db` and seeds the Locations table if it doesn't exist.
- Location codes are seeded like: `W1-A1-R1-B01-L1`. Staging codes: `W1-STAGE-S1-B01`.
- Scanner-friendly inputs: most forms use a single text input (autofocus) so barcode scanners acting as keyboards will work.
- This is a minimal example focused on working code; you can extend it with authentication, CSV import/export, REST API, or more validations.

If you want, I can:
- Add an init_db.py script that can be run explicitly to re-seed.
- Add sample shipments and pallets for demo data.
- Add small client-side JS to auto-submit scan inputs on Enter.
```
``` 

How to run (summary)
- Create virtualenv and install: pip install -r requirements.txt
- Start the app: python app.py
- Visit: http://127.0.0.1:5000/

If you want, I can now:
- Add an explicit init_db.py to seed demo pallets/shipments.
- Provide sample data to try inbound/outbound flows.